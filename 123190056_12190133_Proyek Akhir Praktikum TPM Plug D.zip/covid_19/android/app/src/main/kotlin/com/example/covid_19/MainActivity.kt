package com.example.covid_19

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
